
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Đổi Mật Khẩu</title>
</head>
<body>
    <h2>Đổi Mật Khẩu</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
        Mật khẩu cũ: <input type="password" name="mat_khau_cu" required><br>
        Mật khẩu mới: <input type="password" name="mat_khau_moi" required><br>
        Nhập lại mật khẩu mới: <input type="password" name="nhap_lai_mat_khau_moi" required><br>
        <input type="submit" value="Đổi Mật Khẩu">
    </form>
</body>
</html>
<?php
session_start();
// Kiểm tra xem người dùng đã đăng nhập chưa
if (!isset($_SESSION['id'])) {
    // Nếu chưa, chuyển hướng đến trang đăng nhập
    header('Location: formdangnhap');
    exit();
}

// Kết nối cơ sở dữ liệu
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlbanhang";
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Khi người dùng gửi form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_SESSION['id']; // Lấy ID từ session
    $mat_khau_cu = md5($_POST['mat_khau_cu']);
    $mat_khau_moi = $_POST['mat_khau_moi'];
    $nhap_lai_mat_khau_moi = $_POST['nhap_lai_mat_khau_moi'];

    // Kiểm tra mật khẩu cũ
    $sql = "SELECT password FROM customers WHERE id = '$id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    if ($mat_khau_cu != $row['password']) {
        echo "Mật khẩu cũ không đúng.";
    } elseif ($mat_khau_moi != $nhap_lai_mat_khau_moi) {
        echo "Mật khẩu mới và mật khẩu nhập lại không khớp.";
    } elseif ($mat_khau_cu == md5($mat_khau_moi)) {
        echo "Mật khẩu mới không được giống mật khẩu cũ.";
    } else {
        // Cập nhật mật khẩu mới vào CSDL
        $mat_khau_moi_md5 = md5($mat_khau_moi);
        $sql = "UPDATE customers SET password = '$mat_khau_moi_md5' WHERE id = '$id'";
        if ($conn->query($sql) === TRUE) {
            echo "Mật khẩu đã được thay đổi thành công.";
        } else {
            echo "Lỗi: " . $conn->error;
        }
    }
}

$conn->close();
?>

